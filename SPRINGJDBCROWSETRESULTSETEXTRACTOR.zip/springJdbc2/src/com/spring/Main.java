package com.spring;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter BID,BMODEL,bPrice");
		int bid=sc.nextInt();
		String bmodel=sc.next();
		double price=sc.nextDouble();
		ApplicationContext c=new ClassPathXmlApplicationContext("applicationContext.xml");
		BikeDao g=(BikeDao) c.getBean("e1");
		g.insert(new Bike(bid,bmodel,price));
		System.out.println("data inserted");
		List<Bike> l1=g.display();
		for(Bike y:l1)
		{
			System.out.println(l1);
		}
		System.out.println("to get specfic bike data");
		List<Bike>l2=g.getPerdata();
		for(Bike y:l2)
		{
			System.out.println(y);
		}
	}

}
