package com.spring;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class BikeDao {
	private JdbcTemplate jd;

	NamedParameterJdbcTemplate t;

	public JdbcTemplate getJd() {
		return jd;
	}

	public void setJd(JdbcTemplate jd) {
		this.jd = jd;
	}
	public Boolean insert(Bike b)
	{
		String s="insert into bike values(?,?,?)";
		return jd.execute(s, new PreparedStatementCallback<Boolean>() {

			@Override
			public Boolean doInPreparedStatement(PreparedStatement arg0) throws SQLException, DataAccessException {
				arg0.setInt(1,b.getBid());
				arg0.setString(2,b.getBmodel());
				arg0.setDouble(3,b.getPrice());
				
				return arg0.execute();
			}
			
		});
	}
		public List <Bike> display()
		{
			return jd.query("select * from bike",new ResultSetExtractor<List<Bike>>()
					{

						@Override
						public List<Bike> extractData(ResultSet rs) throws SQLException, DataAccessException {
							List<Bike> l=new ArrayList<>();
							while(rs.next())
							{
								Bike b=new Bike();
								b.setBid(rs.getInt(1));
								b.setBmodel(rs.getString(2));
								b.setPrice(rs.getDouble(3));
								l.add(b);
							}
							return l;
						}
				
					});
			
		}
		public List<Bike> getPerdata()
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("enter bid to get");
			int i=sc.nextInt();
			String s=Integer.toString(i);
			String q="select * from bike where bid=".concat(s);
			return jd.query(q,new RowMapper<Bike>()
				{
					@Override
				public Bike mapRow(ResultSet rs, int rownumber) throws SQLException {
							Bike b1=new Bike();
							b1.setBid(rs.getInt(1));
							b1.setBmodel(rs.getString(2));
							b1.setPrice(rs.getDouble(3));
							return b1;
						}
				
					});
			
		}
		
}
