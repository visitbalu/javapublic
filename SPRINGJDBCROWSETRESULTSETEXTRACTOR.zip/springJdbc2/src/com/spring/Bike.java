package com.spring;

public class Bike {
private int bid;
private String bmodel;
private double price;
public Bike() {
	super();
	// TODO Auto-generated constructor stub
}
public Bike(int bid, String bmodel, double price) {
	super();
	this.bid = bid;
	this.bmodel = bmodel;
	this.price = price;
}
public int getBid() {
	return bid;
}
public void setBid(int bid) {
	this.bid = bid;
}
public String getBmodel() {
	return bmodel;
}
public void setBmodel(String bmodel) {
	this.bmodel = bmodel;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
@Override
public String toString() {
	return "Bike [bid=" + bid + ", bmodel=" + bmodel + ", price=" + price + "]";
}

}
