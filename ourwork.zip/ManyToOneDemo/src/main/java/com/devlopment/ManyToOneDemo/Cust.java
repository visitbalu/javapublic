package com.devlopment.ManyToOneDemo;


import javax.persistence.*;
@Entity
@Table (name="Cust")
public class Cust
{
@Id
@Column(name="CUST_ID")
@GeneratedValue(strategy=GenerationType.AUTO)
private int CustId;
@Column(name="Cust_NAME")
private String custName;
public int getCustId() {
 return CustId;
}
public void setCustId(int custId) {
CustId = custId;
}
public String getCustName() {
return custName;
}
public void setCustName(String custName) {
 this.custName = custName;
}
}