package com.devlopment.ManyToOneDemo;


import javax.persistence.*;

@Entity
@Table(name="Bike")
public class Bike{
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
@Column(name="B_ID")
private int BikeId;
@Column(name="Bike_NAME")
private String BikeName;
@ManyToOne
@JoinColumn(name ="CUST_ID")
private Cust cust;
public int getBikeId() {
return BikeId;
}
public void setBikeId(int bikeId) {
 BikeId = bikeId;
}

public String getBikeName() {
return BikeName;
}

public void setBikeName(String bikeName) {
BikeName = bikeName;
}

public Cust getCust() {
 return cust;
}

public void setCust(Cust cust) {
this.cust = cust;
}
}