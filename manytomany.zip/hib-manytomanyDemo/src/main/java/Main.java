import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
public class Main {
public static void main(String[] args) {
Cust c=new Cust();
Bike b1=new Bike();
Bike b2=new Bike();
Bike b3=new Bike();
Bike b4=new Bike();
b1.setBikeName("ktm");
b1.setCust(c);
b2.setBikeName("hero");
b2.setCust(c);
b3.setBikeName("royal");
b3.setCust(c);
b4.setBikeName("Tvs");
b4.setCust(c);
c.setCustName("ajay");
Configuration cfg=new Configuration();
cfg.configure("hibernate.cfg.xml");	        
SessionFactory f = cfg.buildSessionFactory();
Session s = f.openSession();
Transaction  tx = s.beginTransaction();
s.save(b1);
s.save(b2);
s.save(b3);
s.save(b4);
s.save(c);
tx.commit();
s.close();
}
}