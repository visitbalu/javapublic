package com.oneToManyDemo;

public class Vehicle {

}
