import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Generated;

@Entity
@Table
public class Vehicle {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
@Column(name="v_id")
private int vehiceId;
@Column(name="v_name")
private String v_name;
@Column(name="v_price")
private Double price;
public int getVehiceId() {
	return vehiceId;
}
public void setVehiceId(int vehiceId) {
	this.vehiceId = vehiceId;
}
public String getV_name() {
	return v_name;
}
public void setV_name(String v_name) {
	this.v_name = v_name;
}
public Double getPrice() {
	return price;
}
public void setPrice(Double price) {
	this.price = price;
}

}
