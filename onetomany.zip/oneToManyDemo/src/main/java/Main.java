import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		UserDetails u1=new UserDetails();
		Vehicle v1=new Vehicle();
		Vehicle v2=new Vehicle();
		Vehicle v3=new Vehicle();
		System.out.println("Enter 1 st Bike id,model,price");
		//int id1=sc.nextInt();
		String ve1=sc.next();
		double p1=sc.nextDouble();
		System.out.println("Enter 2 nd Bike id,model,price");
		//int id2=sc.nextInt();
		String ve2=sc.next();
		double p2=sc.nextDouble();
		System.out.println("Enter3 rd Bike id model,price");
		//int id3=sc.nextInt();
		String ve3=sc.next();
		double p3=sc.nextDouble();
		//v1.setVehiceId(id1);
		//v2.setVehiceId(id2);
		//v3.setVehiceId(id3);
		v1.setV_name(ve1);
		v1.setPrice(p1);
		v2.setV_name(ve2);
		v2.setPrice(p2);
		v3.setV_name(ve3);
		v3.setPrice(p3);
		System.out.println("enter user id,name");
		//int usid=sc.nextInt();
		String uname=sc.next();
		//u1.setUserId(usid);
		u1.setUserName(uname);
		u1.getVe().add(v1);
		u1.getVe().add(v2);
		u1.getVe().add(v3);
		Configuration cfg=new Configuration();
	    cfg.configure("hibernate.cfg.xml");	        
	    SessionFactory f = cfg.buildSessionFactory();
	    Session s = f.openSession();
	    Transaction  tx = s.beginTransaction();
	    //s.beginTransaction();
	    s.save(v1);
	    s.save(v2);
	    s.save(v3);
	    s.save(u1);
	    tx.commit();
	    s.close();
	}

}
