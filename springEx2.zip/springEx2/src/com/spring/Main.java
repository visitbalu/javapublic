package com.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext con=new ClassPathXmlApplicationContext("appicationContext.xml");
	Iteam i=(Iteam) con.getBean("Iteam");
	System.out.println(i);
	System.out.println("totbillamount:"+i.billamountCal());
	}

}
