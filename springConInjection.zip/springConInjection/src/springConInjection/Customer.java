package springConInjection;

public class Customer {
private Address address;

public Customer(Address address) {
	super();
	this.address = address;
}

@Override
public String toString() {
	return "Customer [address=" + address + "]";
}

}
