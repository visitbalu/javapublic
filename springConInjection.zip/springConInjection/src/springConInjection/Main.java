package springConInjection;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext con=new ClassPathXmlApplicationContext("applicationContext.xml");
		Customer c1=(Customer) con.getBean("cust");
		System.out.println(c1);
	}

}
