package springConInjection;

public class Address {
private String fullAddress;

public Address(String fullAddress) {
	super();
	this.fullAddress = fullAddress;
}

public Address() {
	super();
	// TODO Auto-generated constructor stub
}

public String getFullAddress() {
	return fullAddress;
}

public void setFullAddress(String fullAddress) {
	this.fullAddress = fullAddress;
}

@Override
public String toString() {
	return "Address [fullAddress=" + fullAddress + "]";
}

}
