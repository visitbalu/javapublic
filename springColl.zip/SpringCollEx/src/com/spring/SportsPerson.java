package com.spring;

public class SportsPerson {
private String name;
private String place;
private String sports;
public SportsPerson() {
	super();
	// TODO Auto-generated constructor stub
}
public SportsPerson(String name, String place, String sports) {
	super();
	this.name = name;
	this.place = place;
	this.sports = sports;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPlace() {
	return place;
}
public void setPlace(String place) {
	this.place = place;
}
public String getSports() {
	return sports;
}
public void setSports(String sports) {
	this.sports = sports;
}
@Override
public String toString() {
	return "SportsPerson [name=" + name + ", place=" + place + ", sports=" + sports + "]";
}

}
