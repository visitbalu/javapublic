package com.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext con=new ClassPathXmlApplicationContext("applicationContext.xml");
		SportsPerson p1=(SportsPerson) con.getBean("sports1");
		SportsPerson p2=(SportsPerson) con.getBean("sports2");
		SportsPerson p3=(SportsPerson) con.getBean("sports3");
		SportsPerson p4=(SportsPerson) con.getBean("sports4");
		SportsPerson p5=(SportsPerson) con.getBean("sports6");
		SportsPerson p6=(SportsPerson) con.getBean("sports5");
		SportsPersonSet s=new SportsPersonSet();
		s.add(p1);
		s.add(p2);
		s.add(p3);
		s.add(p4);
		s.add(p5);
		s.add(p6);
		s.add(p6);
		s.dispaly();
	}

}
