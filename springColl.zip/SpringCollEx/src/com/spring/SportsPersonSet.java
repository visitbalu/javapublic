package com.spring;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;

public class SportsPersonSet {
//HashSet<SportsPerson> hs=new HashSet<>(); no inserted ordered data 
	//LinkedHashSet<SportsPerson> hs=new LinkedHashSet<>();
	ArrayList<SportsPerson> hs=new ArrayList<>();
public void add(SportsPerson s)
{
	hs.add(s);
}
public void dispaly()
{
	System.out.println(hs);
}
}
