

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		Configuration cfg=new Configuration();
	    cfg.configure("hibernate.cfg.xml");	        
	    SessionFactory factory = cfg.buildSessionFactory();
	    Session session = factory.openSession();
		Student  s = new Student();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter student id,name,group:");
		int i=sc.nextInt();
		String n=sc.next();
		String g=sc.next();
		s.setStudentId(i);
		s.setStudentName(n);
		s.setGrp(g);
		Address  ad = new Address();
		System.out.println("Enter address id,place");
		int id=sc.nextInt();
		String place=sc.next();
		ad.setAddressId(id);
		ad.setPlace(place);
		ad.setParent(s);
		Transaction  tx = session.beginTransaction();
		session.save(ad);
		tx.commit();
		session.close();
		System.out.println("One to One with annotations is done..!!!!");
		factory.close();
	}
}