package com.devlopment.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.devlopment.model.Employee;

public class EmployeeDao {
private JdbcTemplate jd;

public JdbcTemplate getJd() {
	return jd;
}

public void setJd(JdbcTemplate jd) {
	this.jd = jd;
}
public int insert(Employee e)
{
	String sql="insert into emp values("+e.getSapid()+",'"+e.getName()+"',"+e.getSalary()+")";
	return jd.update(sql);
	
}
public int updateEmployee(Employee e)
{	String s2="update emp set ename='"+e.getName()+"',sal="+e.getSalary()+"where sapid="+e.getSapid()+"";
	return jd.update(s2);
	
}
public int deleteEmpDate(Employee e)
{String s3="delete from emp where sapid='"+e.getSapid()+"'";
	return jd.update(s3);
	
}
}
