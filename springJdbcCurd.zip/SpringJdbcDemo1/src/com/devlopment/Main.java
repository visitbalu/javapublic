package com.devlopment;

import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.devlopment.dao.EmployeeDao;
import com.devlopment.model.Employee;

public class Main {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext con=new ClassPathXmlApplicationContext("applicationContext.xml");
		EmployeeDao e=(EmployeeDao) con.getBean("e1");
		Scanner sc=new Scanner(System.in);
		do
		{
			System.out.println("select u r choice:");
			System.out.println("1.INSERT DATA");
			System.out.println("2.UPDATE DATA");
			System.out.println("3.Delete Data");
			System.out.println("enter u r choice");
			int choice=sc.nextInt();
			int sapid;
			String name;
			double sal;
			switch(choice)
			{
			case 1:
			{
				System.out.println("enter empsapid,name,salary");
				sapid=sc.nextInt();
				name=sc.next();
				sal=sc.nextDouble();
				e.insert(new Employee(sapid,name,sal));
				System.out.println("emp record are inserted");
				break;
			}
			case 2:
			{
				System.out.println("enter empsapid,name,salary");
				sapid=sc.nextInt();
				name=sc.next();
				sal=sc.nextDouble();
				int s=e.updateEmployee(new Employee(sapid,name,sal));
				System.out.println("emp record are updated"+s);
				break;
				
			}
			case 3:
			{
				Employee e1=new Employee();
				System.out.println("enter empsapid");
				sapid=sc.nextInt();
				e1.setSapid(sapid);
				int s=e.deleteEmpDate(e1);
				System.out.println("emp record are Deleted"+s);
				break;
			}
			}
		}while(true);
	}

}
